#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int main(){
long long int x,y;
//srand(time(NULL));
//x=(long double)rand()/(long double)RAND_MAX;
printf("%.10Lf\n",x);
return 0;
}
