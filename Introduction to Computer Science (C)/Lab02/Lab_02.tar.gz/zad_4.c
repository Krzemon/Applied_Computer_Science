#include <stdio.h>

int main(){
int n;
do{
 printf("wpsiz wysokosc trojkata: ");
 scanf("%d",&n);
}while(n<0);

printf("wysokosc=%d\n",n);

for(int i=0; i<n;i++){
 for(int j=0;j<i;j++){
  if()
    printf(" ");
  else
    printf("*");
 }
}
return 0;
}
