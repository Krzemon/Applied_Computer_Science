#include <stdio.h>

int main(){
char a;
do{
 printf("Wpisz litere: ");
 scanf("%c",&a);
}while(a<65 || a>90);
printf("Litera= %c\n",a);



return 0;
}
